package com.lamagiadelazucar.backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Para permitir POST desde frontend
            .authorizeHttpRequests(auth -> auth
                // Deja públicos los endpoints de artículos y login/registro
                .requestMatchers("/articulos/**", "/imagenes/**", "/usuarios/registro", "/usuarios/login").permitAll()
                // Todo lo demás requiere autenticación (cuando la configures)
                .anyRequest().authenticated()
            )
            .httpBasic(Customizer.withDefaults()); // No implementa login todavía, solo para pruebas

        return http.build();
    }
}
